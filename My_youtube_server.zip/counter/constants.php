<?php
$COUNTER_FILENAME = "counter.txt";		// Modify the location of filename as needed
?>