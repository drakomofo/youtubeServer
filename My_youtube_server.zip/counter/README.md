# php-website-visitor-counter

This is a simple PHP website to demonstrate visitor counter in the web page. 

[Click here for the demo](http://francismeynard.github.io/php-website-visitor-counter)
